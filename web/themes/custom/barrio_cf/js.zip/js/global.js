/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.barrio_cf = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
